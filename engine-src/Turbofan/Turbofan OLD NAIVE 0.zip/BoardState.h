#include <iostream>

#pragma once
namespace Turbofan
{
	typedef unsigned char uint8;

	enum class Promotion : uint8
	{
		queen,
		rook,
		bishop,
		knight
	};

	struct Move
	{
		uint8 from : 6;
		uint8 to : 6;
		Promotion promotion : 2;
	};


	enum class Piece : uint8
	{
		vacant,
		bKing,
		bQueen,
		bRook,
		bBishop,
		bKnight,
		bPawn,
		bCRook,
		enPassant,
		wKing,
		wQueen,
		wRook,
		wBishop,
		wKnight,
		wPawn,
		wCRook
	};

	const char pieceChars[16] = { ' ', 'k', 'q', 'r', 'b', 'n', 'p', 'c', '|', 'K', 'Q', 'R', 'B', 'N', 'P', 'C' };

	class BoardState
	{
	public:
		static const unsigned int rankMasks[8];

		unsigned int ranks[8];

		union
		{
			uint8 uHeader; // not sure what best practice for this is or naming conventions
			struct BoardHeader
			{
				uint8 placeHolder : 7;
				bool toMove : 1;
			} header;
		};

	
	public:
		BoardState();
		~BoardState();

		void setFromFEN(char* FEN);

		Piece getPiece(int index);
		void setPiece(int index, Piece piece);
		void makeMove(Move move);

		char* toString();
	};
}