#include <iostream>

#include "BoardState.h"

int main() {
    char *FEN = (char*)"rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
    Turbofan::BoardState testBoard;
    testBoard.setFromFEN(FEN);

    Turbofan::BoardState boardArray[10];

    for (int i = 0; i < 10; i++)
    {
        boardArray[i].setFromFEN(FEN);
    }

    std::cout << "Memory size for one board: " << sizeof(testBoard) << std::endl;
    std::cout << "Memory size for ten boards: " << sizeof(boardArray) << std::endl;

    return 0;
};