#include "BoardState.h"

namespace Turbofan
{
	const unsigned int BoardState::rankMasks[] = {
		0xFFFFFFF0,
		0xFFFFFF0F,
		0xFFFFF0FF,
		0xFFFF0FFF,
		0xFFF0FFFF,
		0xFF0FFFFF,
		0xF0FFFFFF,
		0x0FFFFFFF
	};

	BoardState::BoardState()
	{
		uHeader = (uint8)0x10000000;
	}

	void BoardState::setFromFEN(char* FEN)
	{
		// currently quick and dirty mockup without proper castling support
		// TODO: fix castling
		int rankIndex = 0;
		int fileIndex = 0;
		
		Piece currentPiece = Piece::vacant;
		ranks[rankIndex] = 0x00000000;
		while (*FEN != ' ')
		{
			switch (*FEN)
			{
				// black pieces
			case 'k':
				currentPiece = Piece::bKing;
				break;
			case 'q':
				currentPiece = Piece::bQueen;
				break;
			case 'r':
				currentPiece = Piece::bCRook; // defaults to castleable rooks
				break;
			case 'b':
				currentPiece = Piece::bBishop;
				break;
			case 'n':
				currentPiece = Piece::bKnight;
				break;
			case 'p':
				currentPiece = Piece::bPawn;
				break;

				// white pieces
			case 'K':
				currentPiece = Piece::wKing;
				break;
			case 'Q':
				currentPiece = Piece::wQueen;
				break;
			case 'R':
				currentPiece = Piece::wCRook; // defaults to castleable rook
				break;
			case 'B':
				currentPiece = Piece::wBishop;
				break;
			case 'N':
				currentPiece = Piece::wKnight;
				break;
			case 'P':
				currentPiece = Piece::wPawn;
				break;

			case '/':
				rankIndex++;
				fileIndex = -1; // after increment fileIndex will be 0
				break;

			default: // character is a numeral (from 1 to 8)
				currentPiece = Piece::vacant;
				int s = *FEN - '1'; // number of squares to fill modified from stackoverflow
				while (s > 0) // loop shouldn't enter if character is 1
				{
					ranks[rankIndex] = ranks[rankIndex] << 4;
					ranks[rankIndex] |= (int)currentPiece;

					fileIndex++;
					s--;
				}
				fileIndex = -1;
			}
			ranks[rankIndex] = ranks[rankIndex] << 4;
			ranks[rankIndex] |= (int)currentPiece;
			fileIndex++;

			FEN++;
		}
		// pieces and vacancies done, now other info like castling, en passant, who to move
		//uHeader = (uint8)0x10000000;
		header.toMove = *(++FEN) == 'w' ? true : false;
		FEN++;
		// do castling checks etc...
	}

	Piece BoardState::getPiece(int index)
	{
		/*
		int rank = index / 8;
		int file = index % 8;
		return (Piece)((ranks[rank] >> (file * 4)) % 16);
		*/
		return (Piece)((ranks[index / 8] >> ((index % 8) * 4)) % 16);
	}

	void BoardState::setPiece(int index, Piece piece)
	{
		int rank = index / 8;
		ranks[rank] = (ranks[rank] & rankMasks[rank]) | ((int)piece << ((index % 8) * 4));

		//  original rank: 01101001011010010100101110011111
		// reset mask:     11110000111111111111111111111111 
		//				   AND
		// output:		   01100000011010010100101110011111
		// new piece mask: 00001101000000000000000000000000
		//				   OR
		// new rank:       01101101011010010100101110011111

		/*
		int file = index % 8;
		int resetMask = rankMasks[rank];
		int pieceMask = (int)piece << (file * 4);

		ranks[rank] &= resetMask;
		ranks[rank] |= pieceMask;
		*/
	}

	void BoardState::makeMove(Move move)
	{
		setPiece(move.to, getPiece(move.from));
		ranks[move.from / 8] &= rankMasks[move.from % 8];
	}

	char* BoardState::toString()
	{
		char* board = new char[128];
		int i = 0;

		while (i != 64)
		{
			*(board++) = pieceChars[(int)getPiece(i++)];
			*(board++) = ' ';
		}
		board--;

		*board = '\n';
		board -= 16;
		*board = '\n';
		board -= 16;
		*board = '\n';
		board -= 16;
		*board = '\n';
		board -= 16;
		*board = '\n';
		board -= 16;
		*board = '\n';
		board -= 16;
		*board = '\n';
		board -= 16;
		*board = '\n';
		board -= 16;
		
		return board;
	}

	BoardState::~BoardState()
	{
		delete[] &ranks;
		delete &header;
	}
}